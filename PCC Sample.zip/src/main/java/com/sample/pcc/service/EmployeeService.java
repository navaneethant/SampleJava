/**
 * 
 */
package com.sample.pcc.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.geode.cache.Region;
import org.apache.geode.cache.client.ClientCache;
import org.apache.geode.cache.client.ClientRegionFactory;
import org.apache.geode.cache.client.ClientRegionShortcut;
import org.apache.geode.cache.query.Query;
import org.apache.geode.cache.query.SelectResults;
import org.apache.geode.cache.query.internal.ResultsBag;
import org.apache.geode.pdx.JSONFormatter;
import org.apache.geode.pdx.PdxInstance;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sample.pcc.dto.Employee;

import io.pivotal.ClientInitializer;

/**
 * @author 
 *
 */
@Service
public class EmployeeService {

  private ClientCache cache;
  private ClientRegionFactory<String, String> regionFactory;
  private Region region;

  public EmployeeService() {
    this.cache = new ClientInitializer().getCache();
    regionFactory = cache.createClientRegionFactory(ClientRegionShortcut.PROXY);
  }

  /**
   * Gets the region
   * @return
   */
  public Region getRegion() {
    if (region == null) {
      region = regionFactory.create("SampleCacheNew");
    }
    return region;
  }

  /**
   * Saves the Employee
   * @param employee
   * @param region
   * @throws JsonProcessingException 
   */
  public String saveEmployee(Employee employee) throws JsonProcessingException {
    if (getRegion() != null && employee != null) {
      ObjectMapper mapper = new ObjectMapper();
      String claimJson = mapper.writeValueAsString(employee);
      PdxInstance pdxInstance = JSONFormatter.fromJSON(claimJson);
      if(pdxInstance == null) {
    	  return "Pdx is null";
      }
      System.out.println("Printing employee");
      System.out.println("Employee id : "+employee.getEmployeeId());
      getRegion().put(employee.getEmployeeId(), pdxInstance);
    }
    return "Success";
  }

  /**
   * 
   * @param employeeId
   * @param region
   * @return
 * @throws IOException 
 * @throws JsonMappingException 
 * @throws JsonParseException 
   */
  public Employee getEmployeeById(String employeeId) throws Exception {
    PdxInstance instance = (PdxInstance) getRegion().get(employeeId);
    ObjectMapper mapper = new ObjectMapper();
    String json = JSONFormatter.toJSON(instance);
    return mapper.readValue(json, Employee.class);
  }

  /**
   * 
   * @param employeeId
   * @param region
   * @return
   */
  public List<Employee> getEmployeeByIdQuery(String employeeId) {
    StringBuilder queryString = new StringBuilder();
    queryString.append("select * from /" + getRegion().getName() + " where employeeId='" + employeeId + "'");
    System.out.println("queryString : "+queryString.toString());
    PdxInstance instance = null;
    Employee employee = null;
    List<Employee> employees = null;
    ResultsBag resultBags = null;
    Query query = getRegion().getCache().getQueryService().newQuery(queryString.toString());
    try {
//    	SelectResults<T> results = (SelectResults<T>) query.execute();
//    	 employees = results.asList();
    	//resultBags.g
      instance = (PdxInstance) query.execute();
      ObjectMapper mapper = new ObjectMapper();
      String json = JSONFormatter.toJSON(instance);
      employee =  mapper.readValue(json, Employee.class);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return employees;
  }

  /**
   * 
   * @param searchCriteria
   * @param region
   * @return
   */
  public Employee getBySearchParameters(Map<String, String> searchCriteria) {
    StringBuilder queryString = new StringBuilder();
    queryString.append("select * from /" + getRegion().getName());
    if (searchCriteria != null && !searchCriteria.isEmpty()) {
      queryString.append(" where ");
    }
    boolean appendAnd = true;
    for (String key : searchCriteria.keySet()) {
      if (appendAnd) {
        queryString.append(" and ");
      }
      queryString.append(key + " = '" + searchCriteria.get(key) + "'");
      appendAnd = true;
    }
    PdxInstance instance = null;
    Employee employee = null;
    Query query = getRegion().getCache().getQueryService().newQuery(queryString.toString());
    try {
      instance = (PdxInstance) query.execute();
      ObjectMapper mapper = new ObjectMapper();
      String json = JSONFormatter.toJSON(instance);
      employee =  mapper.readValue(json, Employee.class);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return employee;
  }

}
