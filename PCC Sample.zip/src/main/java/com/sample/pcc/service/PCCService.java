package com.sample.pcc.service;

import java.io.IOException;

import org.apache.geode.cache.Region;
import org.apache.geode.cache.client.ClientCache;
import org.apache.geode.cache.client.ClientRegionFactory;
import org.apache.geode.cache.client.ClientRegionShortcut;
import org.apache.geode.cache.query.FunctionDomainException;
import org.apache.geode.cache.query.NameResolutionException;
import org.apache.geode.cache.query.Query;
import org.apache.geode.cache.query.QueryInvocationTargetException;
import org.apache.geode.cache.query.TypeMismatchException;
import org.apache.geode.pdx.JSONFormatter;
import org.apache.geode.pdx.PdxInstance;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.sample.pcc.dto.Employee;

import io.pivotal.ClientInitializer;

/**
 * This class has all the service methods to support the requests rest end points.
 * 
 * @author 
 *
 */
@Service
public class PCCService {

  private ClientCache cache;

  ClientRegionFactory<String, String> regionFactory;

  public PCCService() {
    this.cache = new ClientInitializer().getCache();
    regionFactory = cache.createClientRegionFactory(ClientRegionShortcut.PROXY);
    // this.r = regionFactory.create("test");
  }

  public Region<String, String> getRegion(String regionName) {
    if (regionName != null) {
      return regionFactory.create(regionName);
    } else {
      return null;
    }
  }

  public void savePlainText(Region r) {

    if (r != null) {
      r.put("379587", "Navaneethan");
    }

  }

  public String savePlainText(String value, Region r) {
    // Math.random();
    if (r != null) {
      r.put("key" + value, value);
    }
    return "key" + value;
  }

  public void saveClaim(Employee claim, Region r) {
    if (r != null && claim != null) {
      /*PdxInstance pdxInstance = cache.createPdxInstanceFactory(Claim.class.getName()).writeObject(claim.getDCN(), claim).create();
      r.put(claim.getDCN(), pdxInstance);*/
      ObjectWriter writer = new ObjectMapper().writer().withDefaultPrettyPrinter();
      try {
        String claimJson = writer.writeValueAsString(claim);
        r.put(claim.getEmployeeId(), claimJson);
      } catch (JsonProcessingException e) {
        e.printStackTrace();
      }
    }
  }

  public Employee getClaim(String claimID, Region r) {
    Employee claim = null;
    if (claimID != null && r != null) {
      String obj = (String) r.get(claimID);
      ObjectMapper mapper = new ObjectMapper();
      try {
        claim = mapper.readValue(obj, Employee.class);
      } catch (IOException e) {
        e.printStackTrace();
      }

      /* if (obj instanceof PdxInstance) {
        PdxInstance inst = (PdxInstance) obj;
        claim = (Claim) inst.getObject();
      }*/
    }
    return claim;
  }

  public void saveClaimPdx(Employee claim, Region r) {
    if (r != null && claim != null) {
      /*PdxInstance pdxInstance = cache.createPdxInstanceFactory(Claim.class.getName()).writeObject(claim.getDCN(), claim).create();
      r.put(claim.getDCN(), pdxInstance);*/
      ObjectWriter writer = new ObjectMapper().writer().withDefaultPrettyPrinter();
      try {
        String claimJson = writer.writeValueAsString(claim);
        PdxInstance pdxInstance = JSONFormatter.fromJSON(claimJson);
        r.put(claim.getEmployeeId(), pdxInstance);
      } catch (JsonProcessingException e) {
        e.printStackTrace();
      }
    }
  }

  public PdxInstance getClaimPdx(String claimID, Region r) {
    PdxInstance instance = null;
    String queryString = "select * from /" + r.getName() + " where dcn = " + claimID;
    Query query = r.getCache().getQueryService().newQuery(queryString);
    try {
      instance = (PdxInstance) query.execute();
    } catch (FunctionDomainException | TypeMismatchException | NameResolutionException | QueryInvocationTargetException e) {
      e.printStackTrace();
    }
    return instance;
  }

  public String getPlainText(String key, Region r) {
    String value = (String) r.get(key);
    return value;

  }

  public void removePlainText(String key, Region r) {
    String value = (String) r.remove(key);
  }

  public Object executeCustomQuery(String query) {
    Object obj = null;
    Query q = cache.getQueryService().newQuery(query);
    try {
      obj = q.execute();
    } catch (Exception e) {
      e.printStackTrace();
      // throws FunctionDomainException, TypeMismatchException,
      // NameResolutionException, QueryInvocationTargetException
    }
    return obj;

  }

}
