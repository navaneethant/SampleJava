/**
 * 
 */
package com.sample.pcc.controller;

import java.util.List;
import java.util.Map;

import org.apache.geode.pdx.PdxInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.sample.pcc.dto.Employee;
import com.sample.pcc.service.EmployeeService;

/**
 * @author 
 *
 */
@RestController
@RequestMapping("/employee")
public class EmployeeController {

  @Autowired
  private EmployeeService service;

  /**
   * 
   * @param employee
   * @return
   * @throws JsonProcessingException
   */
  @PostMapping("/save")
  public String save(@RequestBody Employee employee) throws JsonProcessingException {
    return service.saveEmployee(employee);
  }

  /**
   * 
   * @param employeeId
   * @return
   */
  @GetMapping("/getByEmployeeId")
  public Employee getEmployeeById(String employeeId) throws Exception {
    return service.getEmployeeById(employeeId);
  }

  /**
   * 
   * @param employeeId
   * @return
   */
//  @GetMapping("/getByIdValue")
//  public List<Employee> getEmployeeByIdValue(String employeeId) {
//    return service.getEmployeeByIdQuery(employeeId);
//  }
//
//  /**
//   * 
//   * @param searchCriteria
//   * @return
//   */
//  @PostMapping("/search")
//  public Employee get(Map<String, String> searchCriteria) {
//    return service.getBySearchParameters(searchCriteria);
//  }
}
