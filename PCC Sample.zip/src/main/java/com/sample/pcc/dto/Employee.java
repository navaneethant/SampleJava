package com.sample.pcc.dto;

public class Employee {
	private String employeeId;
	private String employeeName;
	int age;

	/**
	 * @return Get the employeeId
	 */
	public String getEmployeeId() {
		return this.employeeId;
	}

	/**
	 * @param Set employeeId
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return Get the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param set the employeeName
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return Get the age for Employee
	 */
	public int getAge() {
		return age;
	}

	/**
	 * @param set the age Employee
	 */
	public void setAge(int age) {
		this.age = age;
	}

}
