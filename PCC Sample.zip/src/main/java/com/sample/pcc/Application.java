package com.sample.pcc;

import org.apache.geode.cache.Region;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.sample.pcc.service.PCCService;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * @author 
 *
 */
@SpringBootApplication
@EnableSwagger2
public class Application {

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  //configuration need to be added to change the region names, outside the code.

  @Bean
  public Region region() {
    Region r = this.service().getRegion("SamplePDX");
    return r;
  }

  @Bean
  public PCCService service() {
    PCCService service = new PCCService();
    return service;
  }

}
