package io.pivotal;

import java.net.URI;
import java.util.List;
import java.util.Properties;

import org.apache.geode.cache.client.ClientCache;
import org.apache.geode.cache.client.ClientCacheFactory;
import org.springframework.beans.factory.annotation.Value;
/**
 * This class will inialize the client cache factory and sets the ClientCache instance.
 * @author i367737
 *
 */
public class ClientInitializer {

	ClientCache cache;
	
	@Value("${security-client-auth-init}")
	private String securityClientAuthInit;
	
	public ClientInitializer() {
		Properties props = new Properties();		
		if(securityClientAuthInit == null) {
			this.securityClientAuthInit =  "io.pivotal.ClientAuthInitialize.create";
		}
		props.setProperty("security-client-auth-init", this.securityClientAuthInit);
		ClientCacheFactory ccf = new ClientCacheFactory(props);
		try {
			List<URI> locatorList = EnvParser.getInstance().getLocators();
			for (URI locator : locatorList) {
				ccf.addPoolLocator(locator.getHost(), locator.getPort());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		ClientCache client = ccf.create();
		this.cache = client;
	}
	
	/**
	 * @return the cache
	 */
	public ClientCache getCache() {
		return cache;
	}
	
}
